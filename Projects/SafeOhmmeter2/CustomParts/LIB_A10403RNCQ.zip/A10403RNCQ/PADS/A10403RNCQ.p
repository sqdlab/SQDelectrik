*PADS-LIBRARY-PART-TYPES-V9*

A10403RNCQ A10405RNCQE I SWI 7 1 0 0 0
TIMESTAMP 2026.02.12.03.01.05
"On Line Components Part Number" 
"On Line Components Price/Stock" 
"Manufacturer_Name" C & K COMPONENTS
"Manufacturer_Part_Number" A10403RNCQ
"Description" Rotary Switches Rotary
"Datasheet Link" https://www.ckswitches.com/media/1349/arotary.pdf
"Geometry.Height" 20mm
GATE 1 13 0
A10403RNCQ
1 0 U NC
2 0 U NO_1
3 0 U NO_2
4 0 U NO_3
5 0 U NO_4
6 0 U NO_5
7 0 U NO_6
8 0 U NO_7
9 0 U NO_8
10 0 U NO_9
11 0 U NO_10
12 0 U NO_11
A1 0 U COM

*END*
*REMARK* SamacSys ECAD Model
1703110/1895655/2.50/13/2/Switch
